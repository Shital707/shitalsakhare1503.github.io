
const projects = [
  {
    title: 'Human Resource Management System (HRMS)',
    description: 'A full HR system managing employee details, payroll, attendance, and leave modules. Built using PHP backend, MySQL database, and clean frontend design. A practical deep dive into real-world web development.',
    tags: ['PHP', 'HTML', 'CSS', 'MySQL'],
    color: 'from-primary/20 to-glow-secondary/20',
  },
  {
    title: 'Hypertension Data Analysis using PCA',
    description: 'Performed Principal Component Analysis to identify key factors contributing to hypertension. Analyzed patterns based on age, BMI, blood pressure, lifestyle, and medical history. Helped uncover risk clusters to support healthcare insights.',
    tags: ['Python', 'PCA', 'Data Analysis', 'Visualization'],
    color: 'from-glow-secondary/20 to-primary/20',
  },
];

const PortfolioSection = () => {
  return (
    <section id="portfolio" className="relative py-20">
      <div className="section-container">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            My <span className="text-gradient">Portfolio</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-glow-secondary mx-auto rounded-full" />
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Featured projects showcasing my skills and experience
          </p>
        </div>

        <div className="space-y-8 max-w-4xl mx-auto">
          {projects.map((project, index) => (
            <div
              key={project.title}
              className="glass-card neon-border overflow-hidden hover-lift group"
            >
              <div className={`h-2 bg-gradient-to-r ${project.color}`} />
              
              <div className="p-8">
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 text-xs font-mono bg-primary/10 text-primary rounded-full border border-primary/30"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                <h3 className="text-xl md:text-2xl font-mono font-bold mb-4 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                
                <p className="text-muted-foreground leading-relaxed">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

export default PortfolioSection;
