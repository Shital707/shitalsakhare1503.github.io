import { GraduationCap, User, Target } from 'lucide-react';

const education = [
  { year: '2020', degree: '10th Standard', school: 'Shree Dnyaneshwar Vidyalaya' },
  { year: '2022', degree: '12th Standard', school: 'Jeevan Shikshan Madhyamik Vidyalaya' },
  { year: '2025', degree: 'B.Sc. Computer Science', school: 'MIT ACSC College' },
  { year: 'Pursuing', degree: 'M.Sc. Data Science', school: 'MIT ACSC College' },
];

const AboutSection = () => {
  return (
    <section id="about" className="relative py-20">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/5 to-background" />
      
      <div className="section-container relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            About <span className="text-gradient">Me</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-glow-secondary mx-auto rounded-full" />
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Bio Card */}
          <div className="glass-card neon-border p-8 hover-lift">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center">
                <User className="text-primary" size={24} />
              </div>
              <h3 className="text-xl font-mono font-semibold">Who I Am</h3>
            </div>
            <p className="text-muted-foreground leading-relaxed mb-6">
              My name is Shital Suresh Sakhare. I'm a beginner Web Developer with a growing interest in Data Science. I enjoy designing responsive websites, learning new technologies and analyzing data to solve problems.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              I'm motivated, detail-oriented, and eager to improve my skills. My long-term goal is to become a well-rounded tech professional with strong development and analytical abilities.
            </p>
            
            <div className="mt-6 pt-6 border-t border-border flex items-center gap-3">
              <Target className="text-primary" size={20} />
              <span className="text-sm text-muted-foreground">
                <span className="text-primary font-semibold">Fresher</span> — Eager to gain hands-on experience
              </span>
            </div>
          </div>

          {/* Education Timeline */}
          <div className="glass-card neon-border p-8 hover-lift">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center">
                <GraduationCap className="text-primary" size={24} />
              </div>
              <h3 className="text-xl font-mono font-semibold">Education</h3>
            </div>

            <div className="space-y-6">
              {education.map((item, index) => (
                <div key={index} className="relative pl-8 pb-6 last:pb-0">
                  {/* Timeline line */}
                  {index !== education.length - 1 && (
                    <div className="absolute left-[11px] top-6 w-0.5 h-full bg-gradient-to-b from-primary to-transparent" />
                  )}
                  {/* Timeline dot */}
                  <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-primary" />
                  </div>
                  
                  <div>
                    <span className="text-primary font-mono text-sm font-semibold">{item.year}</span>
                    <h4 className="text-foreground font-medium mt-1">{item.degree}</h4>
                    <p className="text-muted-foreground text-sm">{item.school}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
