import { Globe, LineChart, CheckCircle } from 'lucide-react';

const services = [
  {
    icon: Globe,
    title: 'Website Development',
    description: 'Building modern, responsive websites with clean code and elegant design.',
    features: [
      'Responsive website creation',
      'Clean UI using HTML, CSS, PHP',
      'Database integration with MySQL',
    ],
  },
  {
    icon: LineChart,
    title: 'Data Analysis',
    description: 'Transforming raw data into actionable insights for better decision-making.',
    features: [
      'Dataset cleaning and preprocessing',
      'Data visualization & insights',
      'Analytical reports for decision-making',
    ],
  },
];

const ServicesSection = () => {
  return (
    <section id="services" className="relative py-20">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/5 to-background" />
      
      <div className="section-container relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            My <span className="text-gradient">Services</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-glow-secondary mx-auto rounded-full" />
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Services I offer to help bring your digital ideas to reality
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {services.map((service, index) => (
            <div
              key={service.title}
              className="glass-card neon-border p-8 hover-lift group relative overflow-hidden"
            >
              {/* Hover glow effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative z-10">
                <div className="w-16 h-16 rounded-xl bg-primary/20 flex items-center justify-center mb-6 group-hover:neon-glow transition-all duration-300">
                  <service.icon className="w-8 h-8 text-primary" />
                </div>

                <h3 className="text-xl font-mono font-bold mb-3">{service.title}</h3>
                <p className="text-muted-foreground mb-6">{service.description}</p>

                <ul className="space-y-3">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3 text-sm">
                      <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
