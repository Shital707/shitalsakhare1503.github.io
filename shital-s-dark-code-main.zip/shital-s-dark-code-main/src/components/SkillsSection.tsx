import { Code, Database, BarChart3, FileCode, Braces, PieChart, Terminal, Cpu } from 'lucide-react';

const skills = [
  { name: 'Python', icon: Terminal, level: 75 },
  { name: 'HTML', icon: Code, level: 85 },
  { name: 'CSS', icon: FileCode, level: 80 },
  { name: 'PHP', icon: Braces, level: 70 },
  { name: 'Java', icon: Cpu, level: 65 },
  { name: 'Data Analysis', icon: BarChart3, level: 70 },
  { name: 'Data Visualization', icon: PieChart, level: 75 },
  { name: 'C', icon: Database, level: 70 },
];

const SkillsSection = () => {
  return (
    <section id="skills" className="relative py-20">
      <div className="section-container">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            My <span className="text-gradient">Skills</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-glow-secondary mx-auto rounded-full" />
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Technologies and tools I work with to bring ideas to life
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <div
              key={skill.name}
              className="glass-card neon-border p-6 hover-lift group text-center"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Circular Progress */}
              <div className="relative w-24 h-24 mx-auto mb-4">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="currentColor"
                    strokeWidth="6"
                    fill="none"
                    className="text-secondary"
                  />
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="url(#gradient)"
                    strokeWidth="6"
                    fill="none"
                    strokeLinecap="round"
                    strokeDasharray={`${skill.level * 2.51} 251`}
                    className="transition-all duration-1000 ease-out"
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="hsl(175 80% 50%)" />
                      <stop offset="100%" stopColor="hsl(200 80% 60%)" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <skill.icon className="w-8 h-8 text-primary group-hover:scale-110 transition-transform duration-300" />
                </div>
              </div>

              <h3 className="font-mono font-semibold text-foreground mb-1">{skill.name}</h3>
              <span className="text-sm text-muted-foreground">{skill.level}%</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
